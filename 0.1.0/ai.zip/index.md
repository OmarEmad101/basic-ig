# Home - Basic FHIR Implementation Guide v0.1.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://omaremad101.github.io/basic-ig/ImplementationGuide/example.basic.ig | *Version*:0.1.0 |
| Draft as of 2025-12-31 | *Computable Name*:BasicFHIRIG |

# Basic FHIR IG

This is a sample IG with a custom Patient profile.


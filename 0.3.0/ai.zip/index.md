# Home - Basic FHIR Implementation Guide v0.3.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://omaremad101.github.io/basic-ig/ImplementationGuide/example.basic.ig | *Version*:0.3.0 |
| Draft as of 2025-12-31 | *Computable Name*:BasicFHIRIG |

# Basic FHIR IG

This is a sample IG with a custom Patient profile.

Download the full IG package: [example.basic.ig#0.2.0.tgz](downloads/example.basic.ig#0.2.0.tgz)

